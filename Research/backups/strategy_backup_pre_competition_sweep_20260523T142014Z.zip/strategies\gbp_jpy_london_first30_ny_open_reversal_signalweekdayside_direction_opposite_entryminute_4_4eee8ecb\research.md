# GBPJPY London First30 Ny Open Reversal Signalweekdayside

- Status: isolated competition candidate, not live.
- Asset: GBP/JPY (GBPJPY).
- Family: london_first30_ny_open_reversal_signalweekdayside.
- Forward profit factor: 2.33.
- Forward trades: 87.
- Forward total R: 66.64.
- Training profit factor: 1.95.
- Training trades: 35.

## Hypothesis

Session-window return predicts a later same-day session return. Filtered by signalWeekdaySide=2_short.

## Split Protocol

- Parameter ranking uses trades completed before 2022-01-01.
- Qualification metrics use trades entered on or after 2022-01-01.
- This folder is not imported by the live strategy catalog.

## Sources

- https://biblio.ugent.be/publication/8060014
