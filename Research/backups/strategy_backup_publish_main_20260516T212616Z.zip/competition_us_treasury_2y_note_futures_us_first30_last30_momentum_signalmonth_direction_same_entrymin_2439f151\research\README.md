# Competition ZT Us First30 Last30 Momentum Signalmonth

- Asset: US Treasury 2Y Note Futures (ZT)
- Family: us_first30_last30_momentum_signalmonth
- Training PF: 1.02 over 27 trades
- Forward PF: 2.09 over 77 trades

## Hypothesis

Session-window return predicts a later same-day session return. Filtered by signalMonth=10.

## Split

- Parameters were ranked on trades completed before 2022-01-01.
- Forward metrics are trades entered on or after 2022-01-01.

## Sources

- https://www.sciencedirect.com/science/article/abs/pii/S0304405X18301351
