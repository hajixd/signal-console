# Competition 6N Us First30 Last30 Reversal Signalmonth

- Asset: New Zealand Dollar Futures (6N)
- Family: us_first30_last30_reversal_signalmonth
- Training PF: 1.74 over 43 trades
- Forward PF: 2.24 over 75 trades

## Hypothesis

Session-window return predicts a later same-day session return. Filtered by signalMonth=12.

## Split

- Parameters were ranked on trades completed before 2022-01-01.
- Forward metrics are trades entered on or after 2022-01-01.

## Sources

- https://www.sciencedirect.com/science/article/abs/pii/S0304405X18301351
