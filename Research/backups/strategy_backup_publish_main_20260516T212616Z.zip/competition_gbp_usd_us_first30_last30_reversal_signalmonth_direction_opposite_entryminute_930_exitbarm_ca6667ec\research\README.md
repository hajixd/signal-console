# Competition GBPUSD Us First30 Last30 Reversal Signalmonth

- Asset: GBP/USD (GBPUSD)
- Family: us_first30_last30_reversal_signalmonth
- Training PF: 1.45 over 40 trades
- Forward PF: 2.05 over 83 trades

## Hypothesis

Session-window return predicts a later same-day session return. Filtered by signalMonth=10.

## Split

- Parameters were ranked on trades completed before 2022-01-01.
- Forward metrics are trades entered on or after 2022-01-01.

## Sources

- https://www.sciencedirect.com/science/article/abs/pii/S0304405X18301351
