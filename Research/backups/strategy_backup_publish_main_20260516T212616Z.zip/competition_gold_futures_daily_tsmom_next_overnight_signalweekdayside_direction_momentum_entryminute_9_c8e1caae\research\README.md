# Competition GC Daily Tsmom Next Overnight Signalweekdayside

- Asset: Gold Futures (GC)
- Family: daily_tsmom_next_overnight_signalweekdayside
- Training PF: 1.39 over 311 trades
- Forward PF: 2.23 over 116 trades

## Hypothesis

Tests short-horizon own-return continuation/reversal inspired by time-series momentum literature. Filtered by signalWeekdaySide=1_long.

## Split

- Parameters were ranked on trades completed before 2022-01-01.
- Forward metrics are trades entered on or after 2022-01-01.

## Sources

- https://pages.stern.nyu.edu/~lpederse/papers/TimeSeriesMomentum.pdf
