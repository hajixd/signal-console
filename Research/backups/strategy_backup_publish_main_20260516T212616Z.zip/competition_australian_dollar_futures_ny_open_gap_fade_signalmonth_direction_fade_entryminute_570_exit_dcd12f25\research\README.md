# Competition 6A Ny Open Gap Fade Signalmonth

- Asset: Australian Dollar Futures (6A)
- Family: ny_open_gap_fade_signalmonth
- Training PF: 1.40 over 154 trades
- Forward PF: 2.60 over 75 trades

## Hypothesis

Tests whether the overnight gap fades or continues during a specific NY cash-session window. Filtered by signalMonth=2.

## Split

- Parameters were ranked on trades completed before 2022-01-01.
- Forward metrics are trades entered on or after 2022-01-01.

## Sources

- https://papers.ssrn.com/sol3/papers.cfm?abstract_id=1004081
